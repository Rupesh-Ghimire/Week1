swap = (input("Enter any sentences:"));
print(swap.swapcase())